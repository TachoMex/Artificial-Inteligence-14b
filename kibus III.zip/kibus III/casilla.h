#ifndef CASILLA_H
#define CASILLA_H 

class casilla{
	public:
		int tipo;
		int frame;
		int temperatura;
		void dibujar(int,int);
};

#endif